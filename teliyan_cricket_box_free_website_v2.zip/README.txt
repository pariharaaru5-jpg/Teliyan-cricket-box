TELIYAN CRICKET BOX - FREE WEBSITE

Files:
- index.html
- payment-qr.png

IMPORTANT:
1. Open index.html in a browser to test.
2. In index.html, find:
   const WHATSAPP_NUMBER = "91XXXXXXXXXX";
   Replace it with your WhatsApp number, e.g. 919876543210.
3. The current demo stores booked slots only in that browser (localStorage).
   For a real public multi-user booking system, a database/backend is needed.
4. You can publish this free on GitHub Pages, Netlify, or Cloudflare Pages.
